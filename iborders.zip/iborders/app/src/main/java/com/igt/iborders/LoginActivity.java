package com.igt.iborders;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {
    // User name
    private EditText et_Username;
    // Password
    private EditText et_Password;
    // Sign In
    private Button bt_SignIn;


    String URL = "http://57.253.242.201:38080/securityws-V1/SecurityServiceV1?wsdl";
    String NAMESPACE1 = "http://sita.aero/iborders/aras/external/SecurityServiceWSDLTypes/V1";
    String NAMESPACE2 = "http://sita.aero/iborders/aras/external/Security/V1";
    String SOAP_ACTION = "http://sita.aero/iborders/aras/external/SecurityServiceWSDLTypes/V1/AuthenticateAndGetUserDetailsRequest";
    String METHOD_NAME = "AuthenticateAndGetUserDetailsRequest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Initialization
        et_Username = (EditText) findViewById(R.id.et_Username);
        et_Password = (EditText) findViewById(R.id.et_Password);
        bt_SignIn = (Button) findViewById(R.id.bt_SignIn);

        bt_SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoginTask().execute();
            }
        });
    }


    private class LoginTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                LoginActivity.this);

        protected void onPreExecute() {

            this.dialog.setMessage("Logging in...");
            this.dialog.show();

        }

        protected Void doInBackground(final Void... unused) {
            String email = et_Username.getText().toString();
            String password = et_Password.getText().toString();

            SoapObject request = new SoapObject(NAMESPACE1, METHOD_NAME);
            SoapObject userObject = new SoapObject(NAMESPACE1, "UserLoginDetails");

            PropertyInfo userId = new PropertyInfo();
            userId.setNamespace(NAMESPACE2);
            userId.setType(PropertyInfo.STRING_CLASS);
            userId.setName("UserId");
            userId.setValue(email);
            userObject.addProperty(userId);

            PropertyInfo pass = new PropertyInfo();
            pass.setNamespace(NAMESPACE2);
            pass.setType(PropertyInfo.STRING_CLASS);
            pass.setName("Password");
            pass.setValue(password);
            userObject.addProperty(pass);

            request.addSoapObject(userObject);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.implicitTypes = true;
            envelope.setAddAdornments(false);

            envelope.setOutputSoapObject(request);
            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.debug = true;
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
            } catch (HttpResponseException e) {
                Log.e("HTTPLOG", e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOLOG", e.getMessage());
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                Log.e("XMLLOG", e.getMessage());
                e.printStackTrace();
            } //send request

            Object result = null;

            try {
                result = (Object) envelope.getResponse();
                Log.i("RESPONSE", String.valueOf(result)); // see output in the console
            } catch (SoapFault e) {
                Log.e("SOAPLOG", e.getMessage());
                e.printStackTrace();
            }

            if (result != null) {
                Intent I = new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(I);
            } else {

            }

            return null;
        }

    }
}


