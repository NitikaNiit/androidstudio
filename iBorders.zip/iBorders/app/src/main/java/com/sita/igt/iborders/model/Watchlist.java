package com.sita.igt.iborders.model;

import org.ksoap2.serialization.KvmSerializable;
import org.ksoap2.serialization.PropertyInfo;

import java.util.Hashtable;

public class Watchlist implements KvmSerializable {

    public String Code;
    public String Description;
    public String LocalisedDescription;

    public Watchlist(){}


    public Watchlist(String code , String ename, String aname) {

        Code = code;
        Description = ename;
        LocalisedDescription = aname;
    }


    public Object getProperty(int arg0) {

        switch(arg0)
        {
            case 0:
                return Code;
            case 1:
                return Description;
            case 2:
            return LocalisedDescription;
        }

        return null;
    }

    public int getPropertyCount() {
        return 3;
    }

    public void getPropertyInfo(int index, Hashtable arg1, PropertyInfo info) {
        switch(index)
        {
            case 0:
                info.type = PropertyInfo.STRING_CLASS;
                info.name = "Code";
                break;
            case 1:
                info.type = PropertyInfo.STRING_CLASS;
                info.name = "Description";
                break;
            case 2:
                info.type = PropertyInfo.STRING_CLASS;
                info.name = "LocalisedDescription";
                break;
            default:break;
        }
    }

    public void setProperty(int index, Object value) {
        switch(index)
        {
            case 0:
                Code = value.toString();
                break;
            case 1:
                Description = value.toString();
                break;
            case 2:
                LocalisedDescription = value.toString();
                break;
            default:
                break;
        }
    }


}
