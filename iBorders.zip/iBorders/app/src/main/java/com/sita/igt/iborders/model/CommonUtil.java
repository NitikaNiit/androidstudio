package com.sita.igt.iborders.model;

import org.kxml2.kdom.Element;
import org.kxml2.kdom.Node;

public class CommonUtil {

    final String URL = "http://57.253.242.163/WatchlistManagementV3/WatchlistManagementServiceV3.wsdl";
    final String NAMESPACE = "http://sita.aero/iborders/aras/WatchlistManagementServiceWSDLType/V3";
    final String SECURITY_XSD = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
    final String UTILITY_XSD = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";
    final String PASSWORD_XSD = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";

    public Element[] getHeader(){
        Element[] header = new Element[1];
        header[0] = new Element().createElement(SECURITY_XSD,"Security");

        Element usernameToken = new Element().createElement(SECURITY_XSD, "UsernameToken");
        usernameToken.setAttribute(UTILITY_XSD, "Id", "UsernameToken-43C3E535B679262E66152662501168314");
        header[0].addChild(Node.ELEMENT,usernameToken);

        Element username = new Element().createElement(SECURITY_XSD, "Username");
        username.addChild(Node.TEXT,"RIDXYZABC11ZZJAKLSOPPROOSKKkjhfdSSASadfnpsooxmuSAIposom");
        usernameToken.addChild(Node.ELEMENT,username);

        Element pass = new Element().createElement(SECURITY_XSD,"Password");
        pass.setAttribute(null, "Type", PASSWORD_XSD);
        pass.addChild(Node.TEXT, "S1ta@123");
        usernameToken.addChild(Node.ELEMENT, pass);

      return header;
    }

    public String getURL() {
        return URL;
    }

    public String getNAMESPACE() {
        return NAMESPACE;
    }


}
