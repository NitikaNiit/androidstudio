package com.sita.igt.iborders.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;


import com.sita.igt.iborders.model.CommonUtil;
import com.sita.igt.iborders.R;
import com.sita.igt.iborders.model.Watchlist;
import com.sita.igt.iborders.model.WatchlistDetails;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.kxml2.kdom.Element;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import static android.content.ContentValues.TAG;

public class HomeActivity extends AppCompatActivity {

    // Add Button
    private Button bt_Add;
    // Search Button
    private Button bt_Search;
    // Soap Action
    private String SOAP_ACTION = "http://sita.aero/iborders/aras/WatchlistManagementServiceWSDLType/V3/SearchWatchlistRequest";
    // Method Name
    private String METHOD_NAME = "SearchWatchlistRequest";
    // WatchlistDetails Arraylist
    private List<WatchlistDetails> watchlistDetailsList;
    // array of watchlist codes
    private String[] watchlistCodeArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bt_Add = findViewById(R.id.bt_Add);
        bt_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(HomeActivity.this, AddWatchListActivity.class);
                startActivity(I);
            }
        });

        bt_Search = findViewById(R.id.bt_Search);
        bt_Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new HomeActivity.SearchWatchlistTask().execute();
            }
        });
    }

    private class SearchWatchlistTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                HomeActivity.this);

        protected Void doInBackground(final Void... unused) {

            CommonUtil commonUtil = new CommonUtil();
            Element[] header = commonUtil.getHeader();

            String namespace = commonUtil.getNAMESPACE();

            String url = commonUtil.getURL();

            SoapObject request = new SoapObject(namespace, METHOD_NAME);
            SoapObject watchlistObject = new SoapObject(namespace, "WatchlistSearchCriteria");

            PropertyInfo type = new PropertyInfo();
            type.setType(PropertyInfo.STRING_CLASS);
            type.setName("Type");
            type.setValue("B");
            watchlistObject.addProperty(type);

            request.addSoapObject(watchlistObject);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.implicitTypes = true;
            envelope.setAddAdornments(false);

            // add header to envelope
            envelope.headerOut = header;
            Log.i("header", "" + envelope.headerOut.toString());

            envelope.bodyOut = request;
            envelope.setOutputSoapObject(request);
            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(url);
            androidHttpTransport.debug = true;
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
                Log.d("WS", String.valueOf(resultsRequestSOAP));
            } catch (HttpResponseException e) {
                Log.e("HTTPLOG", e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOLOG", e.getMessage());
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                Log.e("XMLLOG", e.getMessage());
                e.printStackTrace();
            } //send request

            Object response = null;

            try {
                response = (Object) envelope.getResponse();
                Log.i("RESPONSE", response.toString()); // see output in the console
            } catch (SoapFault e) {
                Log.e("SOAPLOG", e.getMessage());
                e.printStackTrace();
            }
            if (response != null) {
                String[] watchlistCodeArray = parsingSoapResponse(response);
                Intent I = new Intent(HomeActivity.this, SearchWatchlistActivity.class);
                I.putExtra("WatchlistCodes",watchlistCodeArray);
                startActivity(I);
            } else {

            }

            return null;
        }

        public String[] parsingSoapResponse(Object response) {
            watchlistDetailsList = new ArrayList<WatchlistDetails>();
            PropertyInfo propertyInfo = new PropertyInfo();
            Vector soapResponse = (Vector) response;
            Enumeration enumeration = soapResponse.elements();
            while (enumeration.hasMoreElements()) {
                WatchlistDetails watchlistDetails = new WatchlistDetails();
                SoapObject value = (SoapObject) enumeration.nextElement();
                for (int i = 0; i < value.getPropertyCount(); i++) {
                    value.getPropertyInfo(i, propertyInfo);
                    switch (propertyInfo.name){
                        case "Watchlist":
                            SoapObject watchlist = (SoapObject) value.getProperty("Watchlist");
                            String watchlistCode = watchlist.getPrimitivePropertyAsString("Code");
                            String description = watchlist.getPrimitivePropertyAsString("Description");
                            String localisedDescription = watchlist.getPrimitivePropertyAsString("LocalisedDescription");
                            Log.d(TAG, "Watchlist code: " + watchlistCode);
                            Log.d(TAG, "Description: " + description);
                            Log.d(TAG, "Localised Description: " + localisedDescription);
                            Watchlist watchlistObject = new Watchlist(watchlistCode, description, localisedDescription);
                            watchlistDetails.setWatchlist(watchlistObject);
                            break;
                        case "Type":
                            String type = value.getPropertyAsString("Type");
                            watchlistDetails.setType(type);
                            Log.d(TAG, "Type: " + type);
                            break;
                        case "Owner":
                            String owner = value.getPropertyAsString("Owner");
                            watchlistDetails.setOwner(owner);
                            Log.d(TAG, "Owner: " + owner);
                            break;
                        case "DefaultReasonCode":
                            String defaultReasonCode = value.getPropertyAsString("DefaultReasonCode");
                            watchlistDetails.setDefaultReasonCode(defaultReasonCode);
                            Log.d(TAG, "DefaultReasonCode: " + defaultReasonCode);
                            break;
                        case "WatchlistStatus":
                            String watchlistStatus = value.getPropertyAsString("WatchlistStatus");
                            watchlistDetails.setWatchlistStatus(watchlistStatus);
                            Log.d(TAG, "WatchlistStatus: " + watchlistStatus);
                            break;
                        case "SystemIndicator":
                            String systemIndicator = value.getPropertyAsString("SystemIndicator");
                            watchlistDetails.setSystemIndicator(systemIndicator);
                            Log.d(TAG, "SystemIndicator: " + systemIndicator);
                            break;
                        case "SilentAlert":
                            String silentAlert = value.getPropertyAsString("SilentAlert");
                            watchlistDetails.setSilentAlert(silentAlert);
                            Log.d(TAG, "SilentAlert: " + silentAlert);
                            break;
                        default:
                            Log.d(TAG, "Default Case: " + " No watchlist found");
                    }
                }
                Log.d(TAG, "Watchlist Details: " + watchlistDetails.toString());
                if(watchlistDetails.getWatchlist()!= null)
                    watchlistDetailsList.add(watchlistDetails);
            }

            return sendDataToLayout(); //send data to view after finished parsing.
        }
        private String[] sendDataToLayout() {
            watchlistCodeArray= new String[watchlistDetailsList.size()];
            Iterator iterator = watchlistDetailsList.iterator();
            int i=0;
            while(iterator.hasNext()){
                WatchlistDetails element = (WatchlistDetails) iterator.next();
                Watchlist watchlist = element.getWatchlist();
                String code = (String) watchlist.getProperty(0);
                watchlistCodeArray[i] = code;
                i++;
            }
            return  watchlistCodeArray;
        }
    }
}
