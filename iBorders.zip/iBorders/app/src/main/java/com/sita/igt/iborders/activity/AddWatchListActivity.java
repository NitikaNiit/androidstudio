package com.sita.igt.iborders.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.sita.igt.iborders.model.CommonUtil;
import com.sita.igt.iborders.R;
import com.sita.igt.iborders.model.Watchlist;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;
import java.io.IOException;

public class AddWatchListActivity extends AppCompatActivity {

    // WatchListType
    private EditText watchlistType;
    // WatchListCode
    private EditText watchlistCode;
    // English Name
    private EditText englishName;
    // Arabic Name
    private EditText arabicName;
    // Owner
    private EditText owner;
    // Status
    private EditText status;
    // Add
    private Button add;

    //CommonUtility class to add Namespace, Url and header.
    CommonUtil util = new CommonUtil();

    String URL;
    String NAMESPACE;
    String SOAP_ACTION = NAMESPACE + "/" + "CreateWatchlistRequest";
    String METHOD_NAME = "CreateWatchlistRequest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_watch_list);

        // Initialization
        watchlistType = (EditText) findViewById(R.id.et_wtype);
        watchlistCode = (EditText) findViewById(R.id.et_wcode);
        englishName = (EditText) findViewById(R.id.et_ename);
        arabicName = (EditText) findViewById(R.id.et_aname);
        owner = (EditText) findViewById(R.id.et_owner);
        status = (EditText) findViewById(R.id.et_stat);
        add = (Button) findViewById(R.id.bt_Add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CreateWatchlistTask().execute();
            }
        });
    }

    private class CreateWatchlistTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                AddWatchListActivity.this);

        protected void onPreExecute() {
            this.dialog.setMessage("Adding...");
            this.dialog.show();
        }

        protected Void doInBackground(final Void... unused) {

            URL = util.getURL();
            NAMESPACE = util.getNAMESPACE();

            String WatchlistType = watchlistType.getText().toString();
            String WatchlistCode = watchlistCode.getText().toString();
            String EnglishName = englishName.getText().toString();
            String ArabicName = arabicName.getText().toString();
            String Status = status.getText().toString();
            String Owner = owner.getText().toString();

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
            SoapObject watchlistObject = new SoapObject(NAMESPACE, "WatchlistDetails");

            Watchlist watchlist = new Watchlist();
            watchlist.Code = WatchlistCode;
            watchlist.Description = EnglishName;
            watchlist.LocalisedDescription = ArabicName;

            PropertyInfo pi = new PropertyInfo();
            pi.setName("Watchlist");
            pi.setValue(watchlist);
            pi.setType(watchlist.getClass());
            watchlistObject.addProperty(pi);

            PropertyInfo type = new PropertyInfo();
            type.setType(PropertyInfo.STRING_CLASS);
            type.setName("Type");
            type.setValue(WatchlistType);
            watchlistObject.addProperty(type);

            PropertyInfo ownr = new PropertyInfo();
            ownr.setType(PropertyInfo.STRING_CLASS);
            ownr.setName("Owner");
            ownr.setValue(Owner);
            watchlistObject.addProperty(ownr);

            PropertyInfo wlStatus = new PropertyInfo();
            wlStatus.setType(PropertyInfo.STRING_CLASS);
            wlStatus.setName("WatchlistStatus");
            wlStatus.setValue(Status);
            watchlistObject.addProperty(wlStatus);

            request.addSoapObject(watchlistObject);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.implicitTypes = true;
            envelope.setAddAdornments(false);

            // add header to envelope
            envelope.headerOut = util.getHeader() ;
            Log.i("header", "" + envelope.headerOut.toString());

            envelope.bodyOut = request;
            envelope.setOutputSoapObject(request);
            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.debug = true;

            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
                Log.v("TAG", String.valueOf(resultsRequestSOAP));
            } catch (HttpResponseException e) {
                Log.e("HTTPLOG", e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOLOG", e.getMessage());
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                Log.e("XMLLOG", e.getMessage());
                e.printStackTrace();
            } //send request

            Object result = null;

            try {
                result = (Object) envelope.getResponse();
                Log.i("RESPONSE", String.valueOf(result)); // see output in the console
            } catch (SoapFault e) {
                Log.e("SOAPLOG", e.getMessage());
                e.printStackTrace();
            }

            if (result != null) {
                Intent I = new Intent(AddWatchListActivity.this, HomeActivity.class);
                startActivity(I);
            } else {

            }
            return null;
        }

    }
}
