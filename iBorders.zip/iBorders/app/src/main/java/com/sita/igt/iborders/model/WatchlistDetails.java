package com.sita.igt.iborders.model;

public class WatchlistDetails {

    private Watchlist watchlist;
    private String type;
    private String owner;
    private String defaultReasonCode;
    private String watchlistStatus;
    private String systemIndicator;
    private String SilentAlert;

    public Watchlist getWatchlist() {
        return watchlist;
    }

    public void setWatchlist(Watchlist watchlist) {
        this.watchlist = watchlist;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getDefaultReasonCode() {
        return defaultReasonCode;
    }

    public void setDefaultReasonCode(String defaultReasonCode) {
        this.defaultReasonCode = defaultReasonCode;
    }

    public String getWatchlistStatus() {
        return watchlistStatus;
    }

    public void setWatchlistStatus(String watchlistStatus) {
        this.watchlistStatus = watchlistStatus;
    }

    public String getSystemIndicator() {
        return systemIndicator;
    }

    public void setSystemIndicator(String systemIndicator) {
        this.systemIndicator = systemIndicator;
    }

    public String getSilentAlert() {
        return SilentAlert;
    }

    public void setSilentAlert(String silentAlert) {
        SilentAlert = silentAlert;
    }

    @Override
    public String toString() {
        return "WatchlistDetails{" +
                "watchlist=" + watchlist +
                ", type='" + type + '\'' +
                ", owner='" + owner + '\'' +
                ", defaultReasonCode='" + defaultReasonCode + '\'' +
                ", watchlistStatus='" + watchlistStatus + '\'' +
                ", systemIndicator='" + systemIndicator + '\'' +
                ", SilentAlert='" + SilentAlert + '\'' +
                '}';
    }
}
