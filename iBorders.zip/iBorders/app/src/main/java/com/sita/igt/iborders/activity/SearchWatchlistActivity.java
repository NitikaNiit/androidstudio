package com.sita.igt.iborders.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.sita.igt.iborders.model.CommonUtil;
import com.sita.igt.iborders.R;
import com.sita.igt.iborders.model.WatchlistDetails;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SearchWatchlistActivity extends AppCompatActivity {

    //Type
    private String watchlistType = "B";

    // Search
    private Button search;
    private List<WatchlistDetails> watchlistDetailsList = new ArrayList<>();
    //CommonUtility class to add Namespace, Url and header.
    CommonUtil util = new CommonUtil();

    String URL;
    String NAMESPACE;
    String SOAP_ACTION = NAMESPACE + "/" + "SearchWatchlistRequest";
    String METHOD_NAME = "SearchWatchlistRequest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_watch_list);
        //get the spinner from the xml.
        Spinner dropdown = findViewById(R.id.spinner);
        //create a list of items for the spinner.
        String[] watchlistCodes = getIntent().getStringArrayExtra("WatchlistCodes");
        //create an adapter to describe how the items are displayed.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, watchlistCodes);
        //set the adapter to the spinner.
        dropdown.setAdapter(adapter);

        search = (Button) findViewById(R.id.bt_Search);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SearchWatchlistTask().execute();
            }
        });
    }

    private class SearchWatchlistTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                SearchWatchlistActivity.this);

        protected void onPreExecute() {
            this.dialog.setMessage("Searching...");
            this.dialog.show();
        }

        protected Void doInBackground(final Void... unused) {

            URL = util.getURL();
            NAMESPACE = util.getNAMESPACE();
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
            SoapObject watchlistObject = new SoapObject(NAMESPACE, "WatchlistSearchCriteria");

            PropertyInfo type = new PropertyInfo();
            type.setType(PropertyInfo.STRING_CLASS);
            type.setName("Type");
            type.setValue(watchlistType);
            watchlistObject.addProperty(type);

            request.addSoapObject(watchlistObject);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.implicitTypes = true;
            envelope.setAddAdornments(false);

            // add header to envelope
            envelope.headerOut = util.getHeader() ;
            Log.i("header", "" + envelope.headerOut.toString());

            envelope.bodyOut = request;
            envelope.setOutputSoapObject(request);
            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.debug = true;

            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
                Log.v("TAG", String.valueOf(resultsRequestSOAP));

                if(resultsRequestSOAP!=null){
                    SoapObject root = (SoapObject) resultsRequestSOAP.getProperty(0);

                    System.out.println("Count:"+root.getPropertyCount());
                    for (int i = 0; i < root.getPropertyCount(); i++)
                    {
                        Object property = root.getProperty(i);
                        if (property instanceof SoapObject)
                        {
                            SoapObject category_list = (SoapObject) property;
                            String code = category_list.getProperty("Code").toString();
                            String description = category_list.getProperty("Description").toString();
                            String localisedDescription = category_list.getProperty("LocalisedDescription").toString();


                            System.out.println("Code "+code);
                            System.out.println("Description "+description);
                            System.out.println("LocalisedDescription"+localisedDescription);

                        }
                    }

                }
            } catch (HttpResponseException e) {
                Log.e("HTTPLOG", e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOLOG", e.getMessage());
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                Log.e("XMLLOG", e.getMessage());
                e.printStackTrace();
            } //send request



            Object result = null;
           try {
                result = (Object)envelope.getResponse();
                Log.i("RESPONSE", String.valueOf(result));
                if (result != null) {
                    Intent I = new Intent(SearchWatchlistActivity.this, HomeActivity.class);
                    startActivity(I);
                } else {
                }

            } catch (SoapFault e) {
                Log.e("SOAPLOG", e.getMessage());
                e.printStackTrace();
            }

            return null;
        }

    }
}
