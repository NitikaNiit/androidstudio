package com.sita.igt.iborders.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.sita.igt.iborders.R;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {
    // User name
    private EditText username;
    // Password
    private EditText password;
    // Sign In
    private Button signIn;

    String URL = "http://57.253.242.163/SecurityV1/SecurityServiceV1?wsdl";
    String NAMESPACE1 = "http://sita.aero/iborders/aras/SecurityServiceWSDLType/V1";
    String NAMESPACE2 = "http://sita.aero/iborders/aras/Security/V1";
    String SOAP_ACTION = NAMESPACE1 + "/" + "AuthenticateAndGetUserDetailsRequest";
    String METHOD_NAME = "AuthenticateAndGetUserDetailsRequest";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialization
        username = (EditText) findViewById(R.id.et_Username);
        password = (EditText) findViewById(R.id.et_Password);
        signIn = (Button) findViewById(R.id.bt_SignIn);

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoginTask().execute();
            }
        });
    }

    private class LoginTask extends AsyncTask<Void, Void, Void> {

        private final ProgressDialog dialog = new ProgressDialog(
                LoginActivity.this);

        protected void onPreExecute() {

            this.dialog.setMessage("Logging in...");
            this.dialog.show();

        }

        protected Void doInBackground(final Void... unused) {
            String Username = username.getText().toString();
            String Password = password.getText().toString();

            SoapObject request = new SoapObject(NAMESPACE1, METHOD_NAME);
            SoapObject userObject = new SoapObject(NAMESPACE1, "UserLoginDetails");

            PropertyInfo userId = new PropertyInfo();
            userId.setNamespace(NAMESPACE2);
            userId.setType(PropertyInfo.STRING_CLASS);
            userId.setName("UserId");
            userId.setValue(Username);
            userObject.addProperty(userId);

            PropertyInfo pass = new PropertyInfo();
            pass.setNamespace(NAMESPACE2);
            pass.setType(PropertyInfo.STRING_CLASS);
            pass.setName("Password");
            pass.setValue(Password);
            userObject.addProperty(pass);

            request.addSoapObject(userObject);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.implicitTypes = true;
            envelope.setAddAdornments(false);

            envelope.setOutputSoapObject(request);
            System.out.println(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.debug = true;
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
            } catch (HttpResponseException e) {
                Log.e("HTTPLOG", e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                Log.e("IOLOG", e.getMessage());
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                Log.e("XMLLOG", e.getMessage());
                e.printStackTrace();
            } //send request

            Object result = null;

            try {
                result = (Object) envelope.getResponse();
                Log.i("RESPONSE", String.valueOf(result)); // see output in the console
            } catch (SoapFault e) {
                Log.e("SOAPLOG", e.getMessage());
                e.printStackTrace();
            }

            if (result != null) {
                Intent I = new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(I);
            } else {

            }

            return null;
        }

    }
}


